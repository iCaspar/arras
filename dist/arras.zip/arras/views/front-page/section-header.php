<?php
/**
 * Html for a front page section header.
 *
 * @author: Caspar Green <https://caspar.green/>
 * @package: Arras
 * @since: 4.0.0
 */
?>

<h2 class="home-title"><?php echo $section_header_title; ?></h2>
