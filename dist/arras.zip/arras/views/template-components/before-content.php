<?php
/**
 * HTML before template content.
 *
 * @author: Caspar Green <https://caspar.green/>
 * @package: Arras
 * @since: 4.0.0
 */
?>

<div id="content" class="<?php echo $this->layout->get_classes( 'content' ); ?>">
