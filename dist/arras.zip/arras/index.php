<?php
/**
 *    The Arras theme index.
 */

/**
 * @hooked ICaspar\Arras\Model\Arras::render(), priority 10
 */

do_action('arras');
