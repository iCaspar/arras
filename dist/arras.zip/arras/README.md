# Arras Nova (Arras 4)

## Overview

Arras Nova is a WordPress theme based on the legacy Arras theme.

The 4.0.0-alpla1 version is a minimum viable theme carrying over Arras
1.x styling. The footer message is the single custom option and all
posts are currently restricted to the "traditional tapestry".

By default, Arras Nova's front page is a blog page with a single
section. Setting the front page to a specific page will also result in
a single section of latest posts, though the slideshow and featured
articles sections will be pulled back in before the final 4.0.0
release.

So far, page background colors and images are supported, but logo and 
header images are not yet supported in this alpha.

For more technical details, please see the changelog.md

http://arrastheme.net